import time
import unittest
from Locators.Drivers import drivers
from Locators.locators import Base
from Pages.loginpage import Login


class LoginTestCase(unittest.TestCase):
    def setUp(self):
        dr = drivers()
        base = Base()
        self.driver = dr.newdriver
        driver = self.driver
        driver.maximize_window()
        driver.get(base.URL)

    def test_login(self):
        lp = Login(self.driver)
        lp.login("testmorning","test123")
        time.sleep(10)

    def tearDown(self) -> None:
        self.driver.quit()

