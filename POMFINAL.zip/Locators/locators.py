class locate:
    LogIn = "login2"
    Username = "loginusername"
    Password = "loginpassword"
    Button = '//*[@id="logInModal"]/div/div/div[3]/button[2]'
    ContactURL = '//*[@id="navbarExample"]/ul/li[2]/a'
    EmailID = "recipient-email"
    ContactName = "recipient-name"
    Message = "message-text"
    Button1 ="//*[@id='exampleModal']/div/div/div[3]/button[2]"


class Base:
    URL = "https://demoblaze.com"
    path = "C:\\Selenium\\chromedriver.exe"
